# Catálogo de Mangás e Livros - Trabalho Prático DGT2815

Projeto Angular integrado a servidor **Node.js + Express** e banco **MongoDB (Mongoose)** (`livraria` / coleção `livros`), preservando o tema escuro, as capas em `src/assets/capas/` e o catálogo inicial.

## Pré-requisitos no Linux
- **Node.js** (v18+ recomendado) e **npm**
- **Angular CLI** (`npm install -g @angular/cli` ou via `npx`)
- **MongoDB** (`mongod` / `mongosh` instalado e em execução no Linux)

### Instalando e iniciando o MongoDB no Linux (Ubuntu/Debian)
```bash
sudo apt-get update
sudo apt-get install -y gnupg curl
curl -fsSL https://www.mongodb.org/static/pgp/server-7.0.asc | sudo gpg -o /usr/share/keyrings/mongodb-server-7.0.gpg --dearmor
echo "deb [ signed-by=/usr/share/keyrings/mongodb-server-7.0.gpg ] https://repo.mongodb.org/apt/ubuntu $(lsb_release -cs)/mongodb-org/7.0 multiverse" | sudo tee /etc/apt/sources.list.d/mongodb-org-7.0.list
sudo apt-get update
sudo apt-get install -y mongodb-org
sudo systemctl start mongod
sudo systemctl enable mongod
```

## Como instalar e executar no Linux

### 1. Backend (`livro-server` - Porta `3030`)
Em um terminal:
```bash
cd livro-server
npm install
node seed.js   # Opcional: popula os 6 livros/mangás iniciais se a coleção estiver vazia
npm start      # Inicia o servidor em http://localhost:3030
```

### 2. Frontend (`Angular` - Porta `4200`)
Em outro terminal, na raiz do projeto:
```bash
npm install
ng serve
```
Acesse `http://localhost:4200/`.

## Estrutura do Projeto
- `livro-server/app.js` — Servidor Express na porta `3030` com `cors` e rota `/livros`
- `livro-server/modelo/conexao.js` — Conexão Mongoose com o banco `livraria`
- `livro-server/modelo/livro-schema.js` — Schema e modelo `Livro` na coleção `livros`
- `livro-server/modelo/livro-dao.js` — Operações `obterLivros`, `incluir` e `excluir`
- `livro-server/routes/livros.js` — Endpoints `GET /livros`, `POST /livros` e `DELETE /livros/:codigo`
- `livro-server/seed.js` — Script opcional para carga inicial dos livros/mangás
- `src/app/controle-livros.service.ts` — Consumo da API `http://localhost:3030/livros` via `fetch`
- `src/app/livro-lista/` — Listagem do catálogo em cards com capa e exclusão
- `src/app/livro-dados/` — Formulário de cadastro de novo livro/mangá
- `src/assets/capas/` — Imagens das capas dos livros e mangás
