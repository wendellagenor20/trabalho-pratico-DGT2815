import { Injectable } from '@angular/core';
import { Editora } from './editora';

@Injectable({ providedIn: 'root' })
export class ControleEditoraService {
  editoras: Array<Editora> = [
    { codEditora: 1, nome: 'Panini Comics' },
    { codEditora: 2, nome: 'Editora JBC' },
    { codEditora: 3, nome: 'Rocco' },
    { codEditora: 4, nome: 'Shueisha' },
  ];

  getEditoras(): Array<Editora> {
    return this.editoras;
  }

  getNomeEditora(codEditora: number): string {
    const encontrada = this.editoras.filter((e) => e.codEditora === Number(codEditora));
    return encontrada.length > 0 ? encontrada[0].nome : '';
  }
}
