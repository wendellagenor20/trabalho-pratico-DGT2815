export class Livro {
  _id: string = '';
  codigo: number = 0;
  codEditora: number = 0;
  titulo: string = '';
  resumo: string = '';
  autores: string[] = [];
  capa: string = '';
}
