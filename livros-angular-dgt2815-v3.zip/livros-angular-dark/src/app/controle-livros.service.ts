import { Injectable } from '@angular/core';
import { Livro } from './livro';

const baseURL = 'http://localhost:3030/livros';

interface LivroMongo {
  _id?: string;
  codigo?: number;
  codEditora: number;
  titulo: string;
  resumo: string;
  autores: string[];
  capa?: string;
}

@Injectable({ providedIn: 'root' })
export class ControleLivrosService {
  async obterLivros(): Promise<Array<Livro>> {
    const resposta = await fetch(baseURL, { method: 'GET' });
    if (!resposta.ok) {
      throw new Error(`Erro ao obter livros: ${resposta.status}`);
    }
    const dados: Array<LivroMongo> = await resposta.json();
    return dados.map((item, index) => ({
      _id: item._id ?? '',
      codigo: item.codigo ?? index + 1,
      codEditora: Number(item.codEditora),
      titulo: item.titulo ?? '',
      resumo: item.resumo ?? '',
      autores: Array.isArray(item.autores) ? item.autores : [],
      capa: item.capa && item.capa.trim() !== '' ? item.capa : 'assets/capas/harry1.webp',
    }));
  }

  async incluir(livro: Livro): Promise<boolean> {
    const payload = {
      titulo: livro.titulo,
      codEditora: Number(livro.codEditora),
      resumo: livro.resumo,
      autores: livro.autores,
      capa: livro.capa && livro.capa.trim() !== '' ? livro.capa : 'assets/capas/harry1.webp',
    };

    const resposta = await fetch(baseURL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });

    return resposta.ok;
  }

  async excluir(codigo: string): Promise<boolean> {
    const resposta = await fetch(`${baseURL}/${codigo}`, {
      method: 'DELETE',
    });
    return resposta.ok;
  }
}
