import { Component, OnInit } from '@angular/core';
import { Editora } from '../editora';
import { Livro } from '../livro';
import { ControleEditoraService } from '../controle-editora.service';
import { ControleLivrosService } from '../controle-livros.service';

@Component({
  selector: 'app-livro-lista',
  templateUrl: './livro-lista.component.html',
  styleUrls: ['./livro-lista.component.css']
})
export class LivroListaComponent implements OnInit {
  public editoras: Array<Editora> = [];
  public livros: Array<Livro> = [];

  constructor(
    private servEditora: ControleEditoraService,
    private servLivros: ControleLivrosService
  ) {}

  ngOnInit(): void {
    this.editoras = this.servEditora.getEditoras();
    this.carregarLivros();
  }

  carregarLivros = (): void => {
    this.servLivros.obterLivros()
      .then((livros) => {
        this.livros = livros;
      })
      .catch((err) => {
        console.error('Falha ao carregar livros:', err);
      });
  }

  excluir = (codigo: string): void => {
    this.servLivros.excluir(codigo)
      .then(() => {
        this.carregarLivros();
      })
      .catch((err) => {
        console.error('Falha ao excluir livro:', err);
      });
  }

  obterNome = (codEditora: number): string => {
    return this.servEditora.getNomeEditora(codEditora);
  }
}
