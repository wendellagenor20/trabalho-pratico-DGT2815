const express = require('express');
const router = express.Router();
const livroDao = require('../modelo/livro-dao');

// GET /livros - retorna todos os documentos da coleção livros
router.get('/', async (req, res) => {
  try {
    const livros = await livroDao.obterLivros();
    res.status(200).json(livros);
  } catch (err) {
    res.status(500).json({ erro: 'Erro ao listar livros', detalhes: err.message });
  }
});

// POST /livros - inclui um novo livro no MongoDB
router.post('/', async (req, res) => {
  try {
    const livroCriado = await livroDao.incluir(req.body);
    res.status(201).json(livroCriado);
  } catch (err) {
    res.status(400).json({ erro: 'Erro ao incluir livro', detalhes: err.message });
  }
});

// DELETE /livros/:codigo - exclui livro por _id
router.delete('/:codigo', async (req, res) => {
  try {
    const resultado = await livroDao.excluir(req.params.codigo);
    res.status(200).json({ ok: true, resultado });
  } catch (err) {
    res.status(400).json({ erro: 'Erro ao excluir livro', detalhes: err.message });
  }
});

module.exports = router;
