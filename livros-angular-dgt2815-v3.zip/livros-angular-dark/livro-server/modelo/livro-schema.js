const mongoose = require('./conexao');

const LivroSchema = new mongoose.Schema({
  _id: mongoose.Schema.Types.ObjectId,
  titulo: { type: String, required: true },
  codEditora: { type: Number, required: true },
  resumo: { type: String, default: '' },
  autores: { type: [String], default: [] },
  capa: { type: String, default: 'assets/capas/harry1.webp' }
});

module.exports = mongoose.model('Livro', LivroSchema, 'livros');
