const mongoose = require('mongoose');

const MONGO_URI = process.env.MONGO_URI || 'mongodb://127.0.0.1:27017/livraria';

mongoose.connect(MONGO_URI, {
  dbName: 'livraria'
})
  .then(() => {
    console.log('Conectado ao MongoDB (banco: livraria)');
  })
  .catch((err) => {
    console.error('Erro ao conectar ao MongoDB:', err.message);
  });

module.exports = mongoose;
