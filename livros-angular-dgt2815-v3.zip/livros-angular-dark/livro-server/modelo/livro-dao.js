const mongoose = require('mongoose');
const Livro = require('./livro-schema');

const obterLivros = async () => {
  try {
    return await Livro.find();
  } catch (err) {
    console.error('Erro ao obter livros:', err);
    throw err;
  }
};

const incluir = async (livro) => {
  try {
    const novoLivro = {
      _id: new mongoose.Types.ObjectId(),
      titulo: livro.titulo,
      codEditora: Number(livro.codEditora),
      resumo: livro.resumo || '',
      autores: Array.isArray(livro.autores) ? livro.autores : [],
      capa: livro.capa && livro.capa.trim() !== '' ? livro.capa : 'assets/capas/harry1.webp'
    };
    return await Livro.create(novoLivro);
  } catch (err) {
    console.error('Erro ao incluir livro:', err);
    throw err;
  }
};

const excluir = async (codigo) => {
  try {
    return await Livro.deleteOne({ _id: codigo });
  } catch (err) {
    console.error('Erro ao excluir livro:', err);
    throw err;
  }
};

module.exports = {
  obterLivros,
  incluir,
  excluir
};
