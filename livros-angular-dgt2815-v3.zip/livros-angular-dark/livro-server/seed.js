const mongoose = require('./modelo/conexao');
const Livro = require('./modelo/livro-schema');

const livrosIniciais = [
  {
    _id: new mongoose.Types.ObjectId(),
    codEditora: 3,
    titulo: 'Harry Potter e a Pedra Filosofal',
    resumo: 'Harry descobre que é um bruxo e vai para Hogwarts, onde faz amigos, enfrenta desafios e descobre o segredo da Pedra Filosofal.',
    autores: ['J.K. Rowling'],
    capa: 'assets/capas/harry1.webp'
  },
  {
    _id: new mongoose.Types.ObjectId(),
    codEditora: 1,
    titulo: 'Naruto Vol. 1 - Uzumaki Naruto',
    resumo: 'Naruto é um ninja órfão que sonha em se tornar Hokage, o ninja mais forte da aldeia. Mesmo sendo rejeitado por todos, ele nunca desiste.',
    autores: ['Masashi Kishimoto'],
    capa: 'assets/capas/naruto.webp'
  },
  {
    _id: new mongoose.Types.ObjectId(),
    codEditora: 2,
    titulo: 'One Piece Vol. 1 - Romance Dawn',
    resumo: 'Luffy é um pirata que comeu a Fruta do Diabo e ganhou o poder de esticar como borracha. Ele sai em busca do One Piece para se tornar o Rei dos Piratas.',
    autores: ['Eiichiro Oda'],
    capa: 'assets/capas/onepiece.webp'
  },
  {
    _id: new mongoose.Types.ObjectId(),
    codEditora: 1,
    titulo: 'Dragon Ball Vol. 1',
    resumo: 'Goku é um garoto com rabo de macaco e força sobre-humana que sai em busca das Esferas do Dragão junto com Bulma.',
    autores: ['Akira Toriyama'],
    capa: 'assets/capas/dragonball.webp'
  },
  {
    _id: new mongoose.Types.ObjectId(),
    codEditora: 3,
    titulo: 'Harry Potter e a Câmara Secreta',
    resumo: 'No segundo ano em Hogwarts, Harry enfrenta uma criatura misteriosa que está petrificando os alunos e descobre o segredo da Câmara Secreta.',
    autores: ['J.K. Rowling'],
    capa: 'assets/capas/harry2.webp'
  },
  {
    _id: new mongoose.Types.ObjectId(),
    codEditora: 2,
    titulo: 'Demon Slayer Vol. 1 - Crueldade',
    resumo: 'Tanjiro volta pra casa e encontra sua família morta por demônios. Sua irmã Nezuko sobrevive, mas virou um demônio. Ele vira caçador de demônios para salvá-la.',
    autores: ['Koyoharu Gotouge'],
    capa: 'assets/capas/demonslayer.webp'
  }
];

async function seed() {
  try {
    const count = await Livro.countDocuments();
    if (count === 0) {
      await Livro.insertMany(livrosIniciais);
      console.log('6 livros iniciais inseridos na coleção "livros" do banco "livraria".');
    } else {
      console.log(`A coleção "livros" já possui ${count} documento(s). Nenhum dado duplicado foi inserido.`);
    }
  } catch (err) {
    console.error('Erro ao popular dados iniciais:', err);
  } finally {
    await mongoose.disconnect();
  }
}

setTimeout(seed, 500);
