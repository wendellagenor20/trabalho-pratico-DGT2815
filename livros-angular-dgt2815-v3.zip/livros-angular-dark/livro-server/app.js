const express = require('express');
const cors = require('cors');
const livrosRouter = require('./routes/livros');

const app = express();
const PORT = process.env.PORT || 3030;

app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

app.use('/livros', livrosRouter);

app.listen(PORT, () => {
  console.log(`Servidor Express rodando em http://localhost:${PORT}`);
});

module.exports = app;
